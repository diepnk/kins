library(shiny)
library(plotly)

# 画面UIの定義
ui <- fluidPage(
  
  tags$head(
    tags$link(rel = "stylesheet", type = "text/css", href = "bootstrap.css")
  ),
  
  # Sidebarと入出力の定義
  sidebarLayout(position = "right",
                
                # Sidebar の入力
                sidebarPanel(h2("５年目医療費予測"),
                             verbatimTextOutput("medicalExpenses",placeholder = TRUE),
                             
                             # 入力：Sliderbar
                             sliderInput(inputId = "ketto",
                                         label = "空腹時血糖 mg/dl",
                                         min = 120,
                                         max = 180,
                                         value = 120,
                                         step = 5),
                             sliderInput(inputId = "ketsuatsu",
                                         label = "収縮時血圧 mmHg",
                                         min = 120,
                                         max = 180,
                                         value = 120,
                                         step = 5),
                             sliderInput(inputId = "shibou",
                                         label = "中性脂肪 mg/dl",
                                         min = 120,
                                         max = 240,
                                         value = 120,
                                         step = 5)
                ),
                
                # 出力のMain panel
                mainPanel(h2("５年目病態遷移予測"),
                          
                          plotlyOutput(outputId = "distPlot")
                          
                )
  )
)

# レンダリングロジック
server <- function(input, output) {
  output$distPlot <- renderPlotly({
    
    #血糖グラフ情報の計算(リアルデータがないので、偽のデータを作る)
    inputTemp <- input$ketto
    arrayTemp = c()
    for (x in c(1:51)){
      if(inputTemp < 155){
        arrayTemp <- append(arrayTemp,1)
      }
      else{
        intTemp = (100*sqrt((inputTemp-155)/5)/sqrt(5))
        if (intTemp < 100) {
          arrayTemp <- append(arrayTemp,intTemp)}
        else {
          arrayTemp <- append(arrayTemp,100)}
      }
      inputTemp = inputTemp + 0.5
    }
    trace_ketto <- arrayTemp
    
    #血圧グラフ情報の計算(リアルデータがないので、偽のデータを作る)
    inputTemp <- input$ketsuatsu
    arrayTemp = c()
    for (x in c(1:51)){
      if(inputTemp < 155){
        arrayTemp <- append(arrayTemp,1)
      }
      else{
        intTemp = (100*sqrt((inputTemp-155)/5)/sqrt(5))
        if (intTemp < 100) {arrayTemp <- append(arrayTemp,intTemp+1)}
        else {arrayTemp <- append(arrayTemp,100)}
      }
      inputTemp = inputTemp + 0.5
    }
    trace_ketsuatsu <- arrayTemp
    
    #脂肪グラフ情報の計算(リアルデータがないので、偽のデータを作る)
    inputTemp <- input$shibou
    arrayTemp = c()
    for (x in c(1:51)){
      if(inputTemp < 190 ){
        arrayTemp <- append(arrayTemp,1)
      }
      else{
        intTemp = (100*sqrt((inputTemp-190)/5)/sqrt(5))
        if (intTemp < 100) {
          arrayTemp <- append(arrayTemp,intTemp-1)}
        else{
          arrayTemp <- append(arrayTemp,100)}
      }
      inputTemp = inputTemp + 0.5
    }
    trace_shibou <- arrayTemp
    
    #trace_z(グラフの形を守る為のtrace)
    trace_z = c()
    for(x in c(1:50)){trace_z <- append(trace_z,0)}
    trace_z <- append(trace_z,100)
    
    #x軸
    year = c()
    intTemp <- 0
    for(x in c(1:51)){
      year <- append(year,intTemp)
      intTemp <- intTemp+0.1
    }
    
    #医療費予測計算(リアルデータがないので、偽のデータを作る)
    totalExpense <<- 0
    if(trace_ketto[51] > 80){
      totalExpense <<- totalExpense + 8000000}
    else{
      if(trace_ketto[51] > 60){
        totalExpense <<- totalExpense+6000000}
      else{
        if(trace_ketto[51] > 40){
          totalExpense <<- totalExpense+4000000}
        else{
          if(trace_ketto[51] > 20){
            totalExpense <<- otalExpense+2000000}}
      }       
    }
    if(trace_ketsuatsu[51] > 80){
      totalExpense <<- totalExpense + 8000000}
    else{
      if(trace_ketto[51] > 60){
        totalExpense <<- totalExpense + 6000000}
      else{
        if(trace_ketto[51] > 40){
          totalExpense <<- totalExpense + 4000000}
        else{
          if(trace_ketto[51] > 20){
            totalExpense <<- totalExpense + 2000000}}
      }       
    }
    if(trace_shibou[51] > 80){
      totalExpense <<- totalExpense + 8000000}
    else{if(trace_ketto[51] > 60){
      totalExpense <<- totalExpense + 6000000}
      else{if(trace_ketto[51] > 40){
        totalExpense <<- totalExpense + 4000000}
        else{if(trace_ketto[51] > 20){
          totalExpense <<- totalExpense + 2000000}}
      }       
    }
    
    #医療費予測表示
    output$medicalExpenses <- renderText({ 
      as.integer(totalExpense)
    })
    
    #グラフ情報表示
    data <- data.frame(year, trace_ketto, trace_ketsuatsu, trace_shibou,trace_z)
    plot_ly(data, x = ~year, y = ~trace_ketto, name = "血糖", type = "area")%>%
      add_trace(y = ~trace_ketsuatsu, name = '血圧')%>%
      add_trace(y = ~trace_shibou, name = '脂肪')%>%
      add_trace(y = ~trace_z,name = " ", line = list(color = "#FFFFFF"))
    
  })
  
}

# Create Shiny app ----
shinyApp(ui = ui, server = server)
